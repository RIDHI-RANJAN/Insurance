document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("deleteBtn").addEventListener("click", function () {
      var underwriterId = document.getElementById("underwriterId").value.trim();
      var resultMessage = document.getElementById("resultMessage");

      // Ensure field is filled
      if (!underwriterId) {
          showMessage("Please enter an Underwriter ID.", "red");
          return;
      }

      // Convert ID to number for accurate comparison
      underwriterId = Number(underwriterId);

      // Retrieve underwriters from localStorage
      var underwriters = JSON.parse(localStorage.getItem("underwriters")) || [];

      console.log("Before Deletion:", underwriters); // Debugging log

      // Find index of underwriter
      var foundIndex = underwriters.findIndex(underwriter => underwriter.id === underwriterId);

      if (foundIndex !== -1) {
          // Remove underwriter from array
          underwriters.splice(foundIndex, 1);
          localStorage.setItem("underwriters", JSON.stringify(underwriters));

          showMessage(`Underwriter with ID ${underwriterId} has been deleted successfully.`, "green");

          console.log("After Deletion:", underwriters); // Debugging log
      } else {
          showMessage("No such underwriter exists with the given ID.", "red");
      }
  });

  // Function to display success or error messages
  function showMessage(message, color) {
      var resultMessage = document.getElementById("resultMessage");
      resultMessage.style.color = color;
      resultMessage.innerHTML = message;
      resultMessage.style.display = "block";
  }

  // Back Button Action
  document.getElementById("back-btn").addEventListener("click", function () {
      window.location.href = "manage_underwriter.html"; // Redirect to Manage Underwriter page
  });
});
