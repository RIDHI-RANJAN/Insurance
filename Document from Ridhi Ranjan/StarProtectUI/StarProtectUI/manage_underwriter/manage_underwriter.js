document.addEventListener("DOMContentLoaded", function() {
  const registerUnderwriterBtn = document.getElementById("register-underwriter");
  const searchUnderwriterBtn = document.getElementById("search-underwriter");
  const updatePasswordBtn = document.getElementById("update-password");
  const deleteUnderwriterBtn = document.getElementById("delete-underwriter");
  const viewAllUnderwritersBtn = document.getElementById("view-all-underwriters");
  const viewVehiclesBtn = document.getElementById("view-vehicles");
  const backBtn = document.getElementById("back-btn");

  // Navigate to respective pages
  registerUnderwriterBtn.addEventListener("click", function() {
      window.location.href = "/UnderWriterRegistration/underwriter_registration.html";
  });

  searchUnderwriterBtn.addEventListener("click", function() {
      window.location.href = "/search_underwriter/search_underwriter.html";
  });

  updatePasswordBtn.addEventListener("click", function() {
      window.location.href = "/update_underwriter_password/update_underwriter_password.html";
  });

  deleteUnderwriterBtn.addEventListener("click", function() {
      window.location.href = "/delete_underwriter/delete_underwriter.html";
  });

  viewAllUnderwritersBtn.addEventListener("click", function() {
      window.location.href = "view_all_underwriters.html";
  });

  viewVehiclesBtn.addEventListener("click", function() {
      window.location.href = "view_vehicles.html";
  });

  // Go back to the Role Selection screen
  backBtn.addEventListener("click", function() {
      window.location.href = "/index/index.html";
  });
});
