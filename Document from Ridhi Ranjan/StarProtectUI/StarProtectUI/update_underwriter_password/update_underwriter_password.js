document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("updateBtn").addEventListener("click", function () {
      var underwriterId = document.getElementById("underwriterId").value.trim();
      var oldPassword = document.getElementById("oldPassword").value.trim();
      var newPassword = document.getElementById("newPassword").value.trim();
      var confirmPassword = document.getElementById("confirmPassword").value.trim();
      var resultMessage = document.getElementById("resultMessage");

      // Ensure all fields are filled
      if (!underwriterId || !oldPassword || !newPassword || !confirmPassword) {
          showMessage("All fields are required!", "red");
          return;
      }

      // Convert ID to a number
      underwriterId = Number(underwriterId);

      // Retrieve underwriters from localStorage
      var underwriters = JSON.parse(localStorage.getItem("underwriters")) || [];

      console.log("Stored Underwriters:", underwriters); // Debugging output

      // Find the underwriter by ID
      var underwriter = underwriters.find(underwriter => underwriter.id === underwriterId);

      if (!underwriter) {
          showMessage("No such underwriter exists with the given ID.", "red");
          return;
      }

      // Check if old password matches
      if (underwriter.password !== oldPassword) {
          showMessage("Old password is incorrect.", "red");
          return;
      }

      // Check if new passwords match
      if (newPassword !== confirmPassword) {
          showMessage("New password and confirm password do not match.", "red");
          return;
      }

      // Check password format: at least 6 characters, alphanumeric
      var passwordPattern =/^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[a-zA-Z\d@$!%*?&]{8,}$/;


      if (!passwordPattern.test(newPassword)) {
          showMessage("Password must be at least 8 characters long and contain both letters and numbers.", "red");
          return;
      }

      // Update password
      underwriter.password = newPassword;
      localStorage.setItem("underwriters", JSON.stringify(underwriters));

      showMessage(`Password updated successfully for ID: ${underwriterId}`, "green");
  });

  // Back Button Action
  document.getElementById("back-btn").addEventListener("click", function () {
      window.location.href = "manage_underwriter.html"; // Redirect to Manage Underwriter page
  });

  // Function to display success or error messages
  function showMessage(message, color) {
      var resultMessage = document.getElementById("resultMessage");
      resultMessage.style.color = color;
      resultMessage.innerHTML = message;
      resultMessage.style.display = "block";
  }
});
