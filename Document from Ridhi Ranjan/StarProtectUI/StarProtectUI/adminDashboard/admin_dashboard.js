document.addEventListener('DOMContentLoaded', () => {
  // Sidebar navigation links
  document.querySelector('a[href="#underwriterRegistration"]').addEventListener('click', function() {
      window.location.href = "/UnderWriterRegistration/underwriter_registration.html"; // Link to Underwriter Registration page
  });

  document.querySelector('a[href="#manageUnderwriters"]').addEventListener('click', function() {
      window.location.href = "/manage_underwriter/manage_underwriter.html"; // Link to Manage Underwriters page
  });

  document.querySelector('a[href="#vehicleRegistration"]').addEventListener('click', function() {
      window.location.href = "/vehicle_registration.html"; // Link to Vehicle Registration page
  });

  document.querySelector('a[href="#reports"]').addEventListener('click', function() {
      window.location.href = "reports.html"; // Link to Reports page
  });

  document.querySelector('a[href="#logout"]').addEventListener('click', function() {
      alert("Logging out...");
      window.location.href = "/Index/index.html"; // Redirect to login/role selection page
  });

  // Carousel functionality (if carousel exists)
  const carousel = document.querySelector('#carouselExampleIndicators');
  if (carousel) {
      const carouselInstance = new bootstrap.Carousel(carousel, {
          interval: 3000, // Auto-slide every 3 seconds
          wrap: true
      });
  }
});
