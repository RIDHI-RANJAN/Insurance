// underwriter_data.js

// Function to get stored underwriters from localStorage
function getUnderwriters() {
  const storedData = localStorage.getItem("underwriters");
  return storedData ? JSON.parse(storedData) : [];
}

// Function to save underwriters to localStorage
function saveUnderwriter(underwriter) {
  let underwriters = getUnderwriters();
  underwriters.push(underwriter);
  localStorage.setItem("underwriters", JSON.stringify(underwriters));
}

// Function to display stored underwriters (for testing or admin page)
function displayUnderwriters() {
  const underwriters = getUnderwriters();
  console.log("Stored Underwriters:", underwriters);
}

// Call this function wherever you want to display the stored data

function saveUnderwriter(underwriter) {
  let underwriters = JSON.parse(localStorage.getItem('underwriters')) || [];

  // Generate ID (121 + index)
  let newId = 121 + underwriters.length;
  underwriter.id = newId;

  underwriters.push(underwriter);
  localStorage.setItem('underwriters', JSON.stringify(underwriters));
}

function getUnderwriters() {
  return JSON.parse(localStorage.getItem('underwriters')) || [];
}




