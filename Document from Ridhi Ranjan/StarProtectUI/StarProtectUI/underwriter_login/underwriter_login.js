document.addEventListener('DOMContentLoaded', () => {
  const loginBtn = document.getElementById('loginBtn');
  const backBtn = document.getElementById('back-btn');
  const userIdInput = document.getElementById('userId');
  const passwordInput = document.getElementById('password');
  const resultMessage = document.getElementById('resultMessage');

  // Handle login validation
  loginBtn.addEventListener('click', (event) => {
      event.preventDefault(); // Prevent page reload

      const userId = userIdInput.value.trim();
      const password = passwordInput.value.trim();

      // Reset previous error messages
      resultMessage.style.display = "none";
      resultMessage.textContent = "";

      // Validate input fields
      if (!userId || !password) {
          showError("User ID and Password are required.");
          return;
      }

      // Simulated Underwriter login validation
      if (userId === "underwriter" && password === "Underwriter@123") {
          showSuccess("Login successful! Redirecting...");
          setTimeout(() => {
              window.location.href = "underwriter_dashboard.html"; // Redirect on success
          }, 1500);
      } else {
          showError("Invalid User ID or Password.");
      }
  });

  // Back to role selection
  backBtn.addEventListener('click', () => {
      window.location.href = "index.html"; // Redirect to Role Selection Page
  });

  // Function to show error messages
  function showError(message) {
      resultMessage.textContent = message;
      resultMessage.style.color = "red";
      resultMessage.style.display = "block";
  }

  // Function to show success messages
  function showSuccess(message) {
      resultMessage.textContent = message;
      resultMessage.style.color = "green";
      resultMessage.style.display = "block";
  }
});
