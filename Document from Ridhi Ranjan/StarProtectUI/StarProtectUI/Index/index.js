// Role buttons event listeners
document.getElementById('admin-btn').addEventListener('click', function() {
  showLoginForm();
});

// Redirect to Underwriter Login Page
document.getElementById('underwriter-btn').addEventListener('click', function() {
  window.location.href = '/underwriter_login/underwriter_login.html'; // Redirect to the Underwriter Login Page
});

// Check if carousel exists before running it
const slides = document.querySelectorAll('.carousel-slide img');
if (slides.length > 0) {
  let currentSlide = 0;
  const totalSlides = slides.length;

  document.querySelector('.next').addEventListener('click', () => {
      currentSlide = (currentSlide + 1) % totalSlides;
      updateCarousel();
  });

  document.querySelector('.prev').addEventListener('click', () => {
      currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
      updateCarousel();
  });

  function updateCarousel() {
      const offset = -currentSlide * 100;
      document.querySelector('.carousel-slide').style.transform = `translateX(${offset}%)`;
  }
}

// Back to homepage button functionality
// document.getElementById('back-btn').addEventListener('click', function() {
//   window.location.href = 'homepage.html'; // Change this if needed
// });

// Function to display login form (Admin only)
function showLoginForm() {
  document.querySelector('.role-selection').classList.add('hidden');
  document.getElementById('login-form').classList.remove('hidden');
  document.getElementById('error-message').classList.add('hidden');
}


// Form validation & login
document.getElementById('login-btn').addEventListener('click', function(event) {
  event.preventDefault();

  const userId = document.getElementById('userId').value.trim();
  const password = document.getElementById('password').value.trim();
  const errorMessage = document.getElementById('error-message');

  // Ensure fields are not empty
  if (!userId || !password) {
      showError('Both fields are required.');
      return;
  }

  // Check login credentials
  if (userId === 'admin' && password === 'admin123') {
      alert('Admin login successful');
      window.location.href = '/admin_dashboard/dashboard.html'; // Redirect to Admin Dashboard
  } else if (userId === 'underwriter' && password === 'underwriter123') {
      alert('Underwriter login successful');
      window.location.href = 'underwriter_dashboard.html'; // Redirect to Underwriter Dashboard
  } else {
      showError('Invalid credentials, please try again.');
  }
});

// Function to show error messages
function showError(message) {
  const errorMessage = document.getElementById('error-message');
  errorMessage.textContent = message;
  errorMessage.classList.remove('hidden');
  errorMessage.style.display = 'block'; // Ensure it's visible
}